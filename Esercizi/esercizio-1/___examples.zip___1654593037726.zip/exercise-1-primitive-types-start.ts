/**
 * START: Follow the instructions below.
 */

// Add type annotations to each of these variables.

let country = "Italy";

let year = undefined;

let averageTemperature = 23.6;

let visited = true;

let currency = null;

// Change the type annotations on these variables so they are correct.

let population: boolean = 47_450_795;

let isSummer: string = false;

let languages: number = "Spanish, English";

// ----

export {};
